# Third-party Libraries

This document contains information about investigation and consideration of third-party libraries when implementing forms.

## Form.io

[Form.io](https://form.io) is a form and data management platform for serverless form-based applications.
It open-sourced its [form rendering library](https://github.com/formio/angular-formio) and
[form building library](https://github.com/formio/ngFormBuilder).
Although its form builder only has Angular version,
Form.io does provide a [form-rendering library in vanilla Javascript (ES6)](https://github.com/formio/formio.js).
Also, it has provide its React and Vue binding of the form renderer on the GitHub project.

Form.io builder allows users to drag components and arrange them on web page directly.
A JSON is then generated which can be used later to render the form.
It is easy to use, and provides various components for building the form.
For each component, users are custom how values are input, by users entering, by calculating, or by running a snippet of Javascript.
It also supports several basic validation as well as a custom validation running Javascript.
Play with the builder [here](https://codepen.io/travist/full/xVyMjo/).

To render a form, the renderer accepts a JSON object, or a URL from which it fetches the form data in JSON,
then render it directly on the client side. Rendering is not slow, but there is still a visible delay before the form is rendered.
The rendering library is around 26KiB large. See the renderer [here](https://formio.github.io/formio.js/).

Using Form.io would largely shorten our development time (if it could be used directly),
but after investigation in more details, we found the following problems of Form.io.

1. It has strong binding with Bootstrap.

    Form.io renderer is deeply integrated with Bootstrap, class names of Bootstrap is used directly in the source code.
    This problem can be solved in two ways, (1) read the source code and replace all Bootstrap usage with our own CSS framework;
    or (2) use [Bootswatch](https://bootswatch.com/) or our own CSS to render Bootstrap classes in another way,
    which is exemplified [on the official site](http://formio.github.io/formio.js/app/examples/material.html).
    Both solution would cause some extra time.

2. The Angular-only Form.io builder.

    The Form.io builder is written in Angular and only have Angular support.
    It is still okay for us to use Angular because we want to allow developer to choose what they want to use.
    But the builder limits our choices to only one.

3. Lack of complex model.

    Form.io provides a model, but that model is too simple for us. For example, it supports some conditions and validations,
    but does not allow us to change validations based on certain condition. We'll need to recreate its model definition,
    and add features of supporting new models. Also, its model is deeply bound with view,
    this prevents us from render a form on platforms other than web pages.
    We need to talk with mobile team to decide a good way of showing and submitting data on mobile platforms.

4. Components are not suitable for our needs.

    Form.io has many components, however, we can only use few among them. We can use directly some basic components
    like text fields, radios, checkboxes, buttons, etc. But many other complex components might not suit our needs.
    For example, its date picker is using a open-source library [flatpickr](https://github.com/chmln/flatpickr),
    its dropdown boxes is using [Choices](https://github.com/jshjohnson/Choices), etc.
    It also built in several other components like Google Maps, [signature_pad](https://github.com/szimek/signature_pad), etc.
    These are great libraries and we can consider using that,
    but this limits our choices and we need to consider whether these libraries also suits our other needs.
    What's more important, we might need some other components it does not provide.
    For example, we have some text fields which have autocompletion information of train stations, world cities.
    And we can input different values then these choices. Current Form.io does not have such component.

In conclusion, for builder part, we are limited to Angular and if we would like to choose something else, we are on our own.
For renderer part, we have to do big modifications on model, components and CSS.
This is not an easy task because we not only need to create our own thing, we also need to understand how Form.io renderer works.

In addition, we also noticed that Form.io renderer has around 18k lines of source code.
Considering the amount of source code, it is not a very big project to create a renderer from scratch.

We consider using Form.io with modifications is a time-consuming task, costing more time than creating from scratch,
and decide to create our own form builder and renderer.
