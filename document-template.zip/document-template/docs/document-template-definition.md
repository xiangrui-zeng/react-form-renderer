# Proposal of Document Template Definitions

*Document* is a form which users submit. *Document template* defines what data a document contains, and how it looks like.
When defining a document template, we divide it to two parts: model and view.
*Model* defines what data documents created from this template contain,
and *view* defines layout and looks of these documents in different scenarios (like editing, viewing, or on mobile).

## UML

```plantuml
@startuml
enum FieldType {
  String
  Number
  Date
  Time
  ZonedDateTime
  List
  Object
}

DocumentTemplate : version: String

DocumentTemplate "1" *-- "1" Model

Model : creationTime: Date
Model : lastWriteTime: Date
Model : lastWriteBy: String

Model "1" *-- "*" Field

interface Field
Field : name: String
Field : type: FieldType
Field : rules: Rule[]

Field --- FieldType
Field <|-- StringField
Field <|-- ObjectField
Field <|-- ListField

ListField : items: Field

ObjectField : fields: Field[]

Field "1" *-- "*" Rule

DocumentTemplate "1" *-- "*" View

View : creationTime: Date
View : lastWriteTime: Date
View : lastWriteBy: String

note left of View
  One View is defined per layout.
  For example, we might have one web editing view,
  one web approving view, and one mobile editing view.
  Different renderer might support different Controls.
  Some controls might only be available on web/mobile.
end note

View "1" *-- "*" Control

Control : binding: String
Control : type: String
Control : rules: Rule[]

Control "1" *-- "*" Rule

Control <|--- TextBoxControl

note left of TextBoxControl
  One control might only exist on certain platform.
  Renderer needs to define what controls it supports,
  and how they are rendered.
end note

Rule : condition: String
Rule : properties: Map

Rule --- Validation

Validation : validation: String
Validation : message: LocalizableText

Validation --- LocalizableText

LocalizableText : text: String
LocalizableText : localizedText: Map<Locale, String>

note left of LocalizableText
  LocalizableText in JSON is defined either as a string,
  or a dictionary mapping from locale to string.
end note

hide methods
@enduml
```