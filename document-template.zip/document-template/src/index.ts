import { Template, create } from './template';

export {
  create
};
