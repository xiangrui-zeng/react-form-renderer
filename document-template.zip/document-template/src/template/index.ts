import { FieldDef, FieldMap, create as createField, createObject, FieldType } from '../model/field';
import { DataObject, DataValue } from '../data';
import { ViewDef } from '../view';
import { Field } from '../model/field';
import { ListField } from '../model/field/list';
import { ObjectField } from '../model/field/object';

/**
 * Current template version.
 */
export const TEMPLATE_VERSION = '20180201';

const LIST_PATH_REGEX = /^([_A-Za-z][_A-Za-z0-9]*)\[[0-9]*\]$/;

/**
 * Interface of JSON object definitions of templates.
 */
export interface TemplateDef {
  version: string;
  model: FieldDef[];
  views: ViewDef[];
}

/**
 * Template definitions.
 */
export class Template {
  /** Version of template format. */
  public version: string;
  /** Data model of the template. */
  public model: FieldMap;
  /** Views of the template. */
  public views: ViewDef[];

  /**
   * Create a new template definition based on JSON definition.
   *
   * @param def Template definition in JSON object.
   */
  public constructor(def: TemplateDef) {
    this.version = def.version;
    this.model = def.model.reduce((fields, fieldDef) => {
      fields[fieldDef.name] = createField(fieldDef);
      return fields;
    }, {} as FieldMap);
    this.views = def.views;
  }

  /**
   * Create a new empty object based on the template definition.
   *
   * @param keyPath Key path of the object to create.
   */
  public createObject(keyPath: string = ''): DataValue {
    if (keyPath === '') {
      return createObject(this.model);
    }
    const pathComponents = keyPath.split('.');
    let field: Field | Template = this;
    for (let i = 0; i < pathComponents.length; ++i) {
      let fieldMap: FieldMap;
      if (field instanceof Template) {
        fieldMap = field.model;
      } else if (field instanceof ObjectField) {
        fieldMap = field.fields;
      } else if (field instanceof ListField) {
        fieldMap = field.items.fields;
      } else {
        throw new Error('keypath not found');
      }

      let path = pathComponents[i];
      const execArray = LIST_PATH_REGEX.exec(path);
      if (execArray) {
        path = execArray[1];
        if (!fieldMap.hasOwnProperty(path)) {
          throw new Error('keypath not found');
        }
        field = fieldMap[path];
        if (!(field instanceof ListField)) {
          throw new Error('indexer can only be applied on lists');
        }
        if (i === pathComponents.length - 1) {
          return field.createElement();
        }
      } else {
        if (!fieldMap.hasOwnProperty(path)) {
          throw new Error('keypath not found');
        }
        field = fieldMap[path];
        if (field instanceof ListField && i !== pathComponents.length - 1) {
          throw new Error('non-leaf path segment of list requires indexer');
        }
      }
    }
    return field.createObject();
  }

  /**
   * Convert template to JSON definition format.
   */
  public toJSON(): object {
    return {
      version: this.version,
      model: Object.values(this.model),
      views: this.views
    };
  }
}

/**
 * Create a new template definition based on JSON definition.
 *
 * @param template JSON object to deserialize.
 */
export function create(template: object): Template {
  if (!template.hasOwnProperty('version')) {
    throw new Error('unrecognized template format');
  }
  const def = template as TemplateDef;
  if (def.version === TEMPLATE_VERSION) {
    return new Template(def as TemplateDef);
  }
  throw new Error('unrecognized template version');
}

/**
 * Create a new template definition based on a JSON string.
 *
 * @param template JSON string to deserialize.
 */
export function createFromString(template: string): Template {
  return create(JSON.parse(template));
}
