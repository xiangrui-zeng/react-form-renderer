import { Template, TemplateDef, create, createFromString  } from './index';
import { FieldType } from '../model/field';

describe('Template', () => {
  it('should throw an error if "version" field is missing', () => {
    expect(() => create({})).toThrowError('unrecognized template format');
  });

  it('should throw an error if "version" is unknown', () => {
    expect(() => create({ version: 'foo' })).toThrowError('unrecognized template version');
  });

  it('should throw an error if the provided string cannot be parsed as a valid JSON', () => {
    expect(() => createFromString('foo')).toThrow();
  });

  it('should be deserialized and serialized correctly', () => {
    const json = '{"version":"20180201","model":[],"views":[]}';
    const t = createFromString(json);
    expect(JSON.stringify(t)).toBe(json);
  });

  it('should create an empty object correctly', () => {
    const json = {
      version: '20180201',
      model: [
        {
          name: 'entry1',
          type: 'string' as FieldType,
          rules: []
        },
        {
          name: 'entry2',
          type: 'string' as FieldType,
          rules: []
        },
        {
          name: 'list',
          type: 'list' as FieldType,
          rules: [],
          items: {
            name: 'listelement',
            type: 'object' as FieldType,
            rules: [],
            fields: [
              {
                name: 'listentry1',
                type: 'string' as FieldType,
                rules: []
              }
            ]
          }
        },
        {
          name: 'object',
          type: 'object' as FieldType,
          rules: [],
          fields: [
            {
              name: 'objectfield1',
              type: 'string' as FieldType,
              rules: []
            },
            {
              name: 'objectfield2',
              type: 'string' as FieldType,
              rules: []
            }
          ]
        }
      ],
      views: []
    };
    const t = new Template(json as TemplateDef);
    expect(t.createObject()).toEqual({
      entry1: '',
      entry2: '',
      list: [],
      object: {
        objectfield1: '',
        objectfield2: ''
      }
    });
  });

  it('should create objects based on its key path', () => {
    const json = {
      version: '20180201',
      model: [
        {
          name: 'entry1',
          type: 'string' as FieldType,
          rules: []
        },
        {
          name: 'entry2',
          type: 'string' as FieldType,
          rules: []
        },
        {
          name: 'list',
          type: 'list' as FieldType,
          rules: [],
          items: {
            name: 'listelement',
            type: 'object' as FieldType,
            rules: [],
            fields: [
              {
                name: 'listentry1',
                type: 'string' as FieldType,
                rules: []
              },
              {
                name: 'listentry2',
                type: 'object' as FieldType,
                rules: [],
                fields: [
                  {
                    name: 'listentry2field1',
                    type: 'string' as FieldType,
                    rules: []
                  }
                ]
              }
            ]
          }
        },
        {
          name: 'object',
          type: 'object' as FieldType,
          rules: [],
          fields: [
            {
              name: 'objectfield1',
              type: 'string' as FieldType,
              rules: []
            },
            {
              name: 'objectfield2',
              type: 'string' as FieldType,
              rules: []
            }
          ]
        }
      ],
      views: []
    };
    const t = new Template(json as TemplateDef);
    expect(t.createObject('entry1')).toEqual('');
    expect(t.createObject('entry2')).toEqual('');
    expect(t.createObject('list')).toEqual([]);
    expect(t.createObject('list[]')).toEqual({ listentry1: '', listentry2: { listentry2field1: '' } });
    expect(t.createObject('list[0].listentry1')).toEqual('');
    expect(t.createObject('list[0].listentry2')).toEqual({ listentry2field1: '' });
    expect(t.createObject('list[0].listentry2.listentry2field1')).toEqual('');
    expect(t.createObject('object')).toEqual({ objectfield1: '', objectfield2: '' });
    expect(t.createObject('object.objectfield1')).toEqual('');
    expect(t.createObject('object.objectfield2')).toEqual('');
  });

  it('should throw errors if key path is not valid when creating objects', () => {
    const json = {
      version: '20180201',
      model: [
        {
          name: 'entry1',
          type: 'string' as FieldType,
          rules: []
        },
        {
          name: 'entry2',
          type: 'string' as FieldType,
          rules: []
        },
        {
          name: 'list',
          type: 'list' as FieldType,
          rules: [],
          items: {
            name: 'listelement',
            type: 'object' as FieldType,
            rules: [],
            fields: [
              {
                name: 'listentry1',
                type: 'string' as FieldType,
                rules: []
              },
              {
                name: 'listentry2',
                type: 'object' as FieldType,
                rules: [],
                fields: [
                  {
                    name: 'listentry2field1',
                    type: 'string' as FieldType,
                    rules: []
                  }
                ]
              }
            ]
          }
        },
        {
          name: 'object',
          type: 'object' as FieldType,
          rules: [],
          fields: [
            {
              name: 'objectfield1',
              type: 'string' as FieldType,
              rules: []
            },
            {
              name: 'objectfield2',
              type: 'string' as FieldType,
              rules: []
            }
          ]
        }
      ],
      views: []
    };
    const t = new Template(json as TemplateDef);
    expect(() => t.createObject('foo')).toThrowError('keypath not found');
    expect(() => t.createObject('entry2.bar')).toThrowError('keypath not found');
    expect(() => t.createObject('object.foobar')).toThrowError('keypath not found');
    expect(() => t.createObject('entry2[]')).toThrowError('indexer can only be applied on list');
    expect(() => t.createObject('list.listentry1')).toThrowError('non-leaf path segment of list requires indexer');
  });
});
