export interface LocalizedText {
  [locale: string]: string;
}

export type LocalizableText = string | LocalizedText;
