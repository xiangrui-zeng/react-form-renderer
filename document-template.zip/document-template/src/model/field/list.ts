import { FieldDef, FieldMap, create, createObject, FieldType } from './index';
import { Field } from './field';
import { ObjectField } from './object';
import { DataValue } from '../../data';

/**
 * ListField represents a field whose data type is a list. List elements are always objects.
 */
export class ListField extends Field {
  public items: ObjectField;

  public constructor(def: FieldDef) {
    super(def);
    if (!def.items) {
      throw new Error('list item field undefined');
    }
    if (def.items.type !== FieldType.Object) {
      throw new Error('list item can only be objects');
    }
    this.items = create(def.items) as ObjectField;
  }

  public createObject(): DataValue {
    return [];
  }

  public createElement(): DataValue {
    return this.items.createObject();
  }
}
