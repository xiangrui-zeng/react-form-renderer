import { FieldDef } from './index';
import { Field } from './field';
import { DataValue } from '../../data';

/**
 * BooleanField represents a field whose data type is boolean.
 */
export class BooleanField extends Field {
  public constructor(def: FieldDef) {
    super(def);
  }

  public createObject(): DataValue {
    return false;
  }
}
