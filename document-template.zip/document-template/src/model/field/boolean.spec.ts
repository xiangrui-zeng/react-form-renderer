import { FieldDef, FieldType } from './index';
import { BooleanField } from './boolean';

describe('BooleanField', () => {
  it('should be deserialized and serialized properly', () => {
    const json = {
      name: 'foo',
      type: FieldType.Boolean,
      rules: []
    };
    const field = new BooleanField(json as FieldDef);
    expect(JSON.stringify(field)).toEqual(JSON.stringify(json));
  });

  it('should create an empty object correctly', () => {
    const json = {
      name: 'foo',
      type: FieldType.Boolean,
      rules: []
    };
    const field = new BooleanField(json as FieldDef);
    expect(field.createObject()).toEqual(false);
  });
});
