import { FieldDef, FieldType } from './index';
import { DataObject, DataValue } from '../../data';
import { RuleSet } from '../../rule';

/**
 * Base class of fields.
 */
export abstract class Field {
  public name: string;
  public type: FieldType;
  public rules: RuleSet;

  protected constructor(def: FieldDef) {
    this.name = def.name;
    this.type = def.type;
    this.rules = new RuleSet(def.rules);
  }

  /**
   * Create a new empty object based on the field definition.
   */
  public abstract createObject(): DataValue;
}
