import { FieldDef, FieldType } from './index';
import { ObjectField } from './object';

describe('ObjectField', () => {
  it('should be deserialized and serialized properly', () => {
    const json = {
      name: 'foo',
      type: FieldType.List,
      rules: [],
      fields: []
    };
    const field = new ObjectField(json as FieldDef);
    expect(JSON.stringify(field)).toEqual(JSON.stringify(json));
  });

  it('should create an empty object correctly', () => {
    const json = {
      name: 'foo',
      type: FieldType.List,
      rules: [],
      fields: [
        {
          name: 'bar',
          type: FieldType.String,
          rules: []
        }
      ]
    };
    const field = new ObjectField(json as FieldDef);
    expect(field.createObject()).toEqual({ bar: '' });
  });
});
