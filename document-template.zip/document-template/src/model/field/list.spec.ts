import { FieldDef, FieldType } from './index';
import { ListField } from './list';

describe('ListField', () => {
  it('should be deserialized and serialized properly', () => {
    const json = {
      name: 'foo',
      type: FieldType.List,
      rules: [],
      items: {
        name: 'bar',
        type: FieldType.Object,
        rules: [],
        fields: []
      }
    };
    const field = new ListField(json as FieldDef);
    expect(JSON.stringify(field)).toEqual(JSON.stringify(json));
  });

  it('should create an empty object correctly', () => {
    const json = {
      name: 'foo',
      type: FieldType.List,
      rules: [],
      items: {
        name: 'bar',
        type: FieldType.Object,
        rules: [],
        fields: []
      }
    };
    const field = new ListField(json as FieldDef);
    expect(field.createObject()).toEqual([]);
  });

  it('should create a list element correctly', () => {
    const json = {
      name: 'foo',
      type: FieldType.List,
      rules: [],
      items: {
        name: 'foobar',
        type: FieldType.Object,
        fields: [
          {
            name: 'bar',
            type: FieldType.String,
            rules: []
          }
        ],
        rules: []
      }
    };
    const field = new ListField(json as FieldDef);
    expect(field.createObject()).toEqual([]);
    expect(field.createElement()).toEqual({ bar: '' });
  });
});
