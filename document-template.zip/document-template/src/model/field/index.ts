import { RuleDef, Rule } from '../../rule';
import { DataObject, DataValue } from '../../data';
import { LocalizableText } from '../../localization';
import { Field } from './field';
import { StringField } from './string';
import { BooleanField } from './boolean';
import { ObjectField } from './object';
import { ListField } from './list';

/**
 * Types of field.
 */
export const enum FieldType {
  String = 'string',
  Number = 'number',
  Boolean = 'boolean',
  Date = 'date',
  Time = 'time',
  ZonedDateTime = 'zonedDateTime',
  File = 'file',
  List = 'list',
  Object = 'object'
}

/**
 * Interface of JSON object definition of fields.
 */
export interface FieldDef {
  name: string;
  type: FieldType;
  rules: RuleDef[];
  items?: FieldDef;
  fields?: FieldDef[];
}

/**
 * Interface of field mappings.
 */
export interface FieldMap {
  [name: string]: Field;
}

/**
 * Create an empty data object from a field mapping.
 *
 * @param fields Map of fields in the data object.
 */
export function createObject(fields: FieldMap): DataObject {
  return Object.values(fields).reduce((value, field) => {
    value[field.name] = field.createObject();
    return value;
  }, {} as DataObject);
}

/**
 * Create a new field definition based on JSON definition.
 *
 * @param def JSON definition of a field.
 */
export function create(def: FieldDef): Field {
  switch (def.type) {
    case FieldType.String:
    case FieldType.Number:
    case FieldType.Date:
    case FieldType.Time:
    case FieldType.ZonedDateTime:
    case FieldType.File:
      return new StringField(def);
    case FieldType.Boolean:
      return new BooleanField(def);
    case FieldType.List:
      return new ListField(def);
    case FieldType.Object:
      return new ObjectField(def);
    default:
      throw new Error('unrecognized field type');
  }
}

export {
  Field
};
