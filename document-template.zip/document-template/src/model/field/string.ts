import { FieldDef } from './index';
import { Field } from './field';
import { DataValue } from '../../data';

/**
 * StringField represents a field whose data type is string.
 */
export class StringField extends Field {
  public constructor(def: FieldDef) {
    super(def);
  }

  public createObject(): DataValue {
    return '';
  }
}
