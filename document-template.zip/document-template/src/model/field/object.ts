import { FieldDef, FieldMap, create, createObject } from './index';
import { Field } from './field';
import { DataValue } from '../../data';

/**
 * ObjectField represents a field whose data type is object.
 */
export class ObjectField extends Field {
  public fields: FieldMap;

  public constructor(def: FieldDef) {
    super(def);
    if (!def.fields) {
      throw new Error('object fields undefined');
    }
    this.fields = def.fields.reduce((fields, fieldDef) => {
      fields[fieldDef.name] = create(fieldDef);
      return fields;
    }, {} as FieldMap);
  }

  public createObject(): DataValue {
    return createObject(this.fields);
  }

  public toJSON(): object {
    return {
      name: this.name,
      type: this.type,
      rules: this.rules,
      fields: Object.values(this.fields)
    };
  }
}
