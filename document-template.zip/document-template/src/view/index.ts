import { ControlDef } from './control';

export interface ViewDef {
  controls: ControlDef[];
}
