import { RuleDef } from '../rule';

export interface ControlDef {
  binding: string;
  type: string;
  rules: RuleDef[];
  controls?: ControlDef[];
}
