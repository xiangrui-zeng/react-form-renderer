/**
 * Interface of data objects.
 */
export interface DataObject {
  [key: string]: DataValue;
}

/**
 * Type of data values.
 */
export type DataValue = null | string | boolean | DataObject | DataObject[];
