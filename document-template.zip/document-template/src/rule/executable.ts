export interface Script {
  javascript: string;
}

export type Executable = string | Script;
