import { ValidatorDef, Validator } from './validator';
import { NonEmptyValidator, NAME as NON_EMPTY_VALIDATOR_NAME } from './nonEmpty';

/**
 * Interface of validator mapping.
 */
interface ValidatorMap {
  [name: string]: new (def: ValidatorDef) => Validator;
}

/**
 * Factory class for all validators.
 */
class Factory {
  private validatorMap: ValidatorMap = {};

  public register(name: string, validator: new (def: ValidatorDef) => Validator): void {
    if (this.validatorMap.hasOwnProperty(name)) {
      throw new Error(`duplication validator registration: ${name}`);
    }
    this.validatorMap[name] = validator;
  }

  public isRegistered(name: string): boolean {
    return this.validatorMap.hasOwnProperty(name);
  }

  public create(name: string, def: ValidatorDef): Validator {
    if (!this.isRegistered(name)) {
      throw new Error(`unrecognized validator: ${name}`);
    }
    const creator = this.validatorMap[name];
    return new creator(def);
  }
}

export const FACTORY = new Factory();

FACTORY.register(NON_EMPTY_VALIDATOR_NAME, NonEmptyValidator);
