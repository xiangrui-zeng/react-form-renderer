import { ComplexPropertyValue } from '../property';
import { Executable } from '../executable';
import { LocalizableText } from '../../localization';

/**
 * Interface of validators in JSON definition.
 */
export interface ValidatorDef extends ComplexPropertyValue {
  validation?: Executable;
  message: LocalizableText;
}

/**
 * Base class of validators.
 */
export abstract class Validator {
  public message: LocalizableText;

  protected constructor(def: ValidatorDef) {
    this.message = def.message;
  }
}
