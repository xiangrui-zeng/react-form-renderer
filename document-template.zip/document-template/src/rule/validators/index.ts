import { FACTORY } from './factory';
import { ValidatorDef, Validator } from './validator';

/**
 * Validator factory.
 */
export const Factory = FACTORY;

export {
  ValidatorDef,
  Validator
};
