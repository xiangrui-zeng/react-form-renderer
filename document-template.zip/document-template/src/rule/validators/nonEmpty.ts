import { Validator, ValidatorDef } from './validator';

export const NAME = 'nonEmpty';

export class NonEmptyValidator extends Validator {
  public constructor(def: ValidatorDef) {
    super(def);
  }
}
