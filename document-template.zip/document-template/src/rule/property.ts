import { LocalizableText } from '../localization';
import { Validator } from './validators/index';

/**
 * Interface for all property values with complex type.
 */
export interface ComplexPropertyValue { }

/**
 * Type of all property values.
 */
export type PropertyValue = null | string | boolean | number | Date | LocalizableText | ComplexPropertyValue |
  Validator;

/**
 * Interface of objects representing properties.
 */
export interface Properties {
  [property: string]: PropertyValue;
}
