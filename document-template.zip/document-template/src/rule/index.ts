import { Executable } from './executable';
import { Properties } from './property';
import { ValidatorDef, Factory as ValidatorFactory } from './validators';

/**
 * Interface of rules in JSON definitions.
 */
export interface RuleDef {
  condition?: Executable;
  properties: Properties;
}

/**
 * Rule definition.
 */
export class Rule {
  public condition?: Executable;
  public properties: Properties;

  public constructor(def: RuleDef) {
    this.condition = def.condition;
    this.properties = Object.keys(def.properties).reduce((props, key) => {
      const value = def.properties[key];
      if (ValidatorFactory.isRegistered(key)) {
        props[key] = ValidatorFactory.create(key, value as ValidatorDef);
      } else {
        props[key] = value;
      }
      return props;
    }, {} as Properties);
  }
}

/**
 * A set of rules.
 */
export class RuleSet {
  private rules: Rule[];

  public constructor(ruleDefs: RuleDef[]) {
    this.rules = ruleDefs.map(def => new Rule(def));
  }

  /**
   * Get merged properties.
   */
  public properties(): Properties {
    const properties: Properties = {};
    for (const rule of this.rules) {
      Object.assign(properties, rule.properties);
    }
    return properties;
  }

  /**
   * Convert the rule set to JSON definition format.
   */
  public toJSON(): object {
    return this.rules;
  }
}
