import { RuleSet, RuleDef } from './index';
import { NonEmptyValidator } from './validators/nonEmpty';

describe('RuleSet', () => {
  it('should be deserialized and serialized properly', () => {
    const json = [
      {
        properties: {
          defaultValue: 'foo'
        }
      },
      {
        properties: {
          nonEmpty: {
            message: 'This field cannot be empty.'
          }
        }
      }
    ];
    const ruleSet = new RuleSet(json as RuleDef[]);
    expect(JSON.stringify(ruleSet)).toEqual(JSON.stringify(json));
  });

  it('should merge properties correctly', () => {
    const json = [
      {
        properties: {
          defaultValue: 'foo'
        }
      },
      {
        properties: {
          nonEmpty: {
            message: 'This field cannot be empty.'
          }
        }
      }
    ];
    const ruleSet = new RuleSet(json as RuleDef[]);
    expect(Object.keys(ruleSet.properties())).toEqual(['defaultValue', 'nonEmpty']);
  });

  it('should create validators for certain properties', () => {
    const json = [
      {
        properties: {
          defaultValue: 'foo'
        }
      },
      {
        properties: {
          nonEmpty: {
            message: 'This field cannot be empty.'
          }
        }
      }
    ];
    const ruleSet = new RuleSet(json as RuleDef[]);
    expect(ruleSet.properties().nonEmpty instanceof NonEmptyValidator).toBeTruthy();
  });
});
